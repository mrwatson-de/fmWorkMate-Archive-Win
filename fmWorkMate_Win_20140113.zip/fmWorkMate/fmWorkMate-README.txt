fmWorkMate: Makes FileMaker Work
================================

Copyright © 2014 MrWatson of www.mrwatson.de

Congratulations, you now have the FREE BETA version of the FileMaker productivity tool fmWorkMate from MrWatson of www.mrwatson.de

          NEW - and with huge thanks to the fantastic new MBS-Plugin v3.5 from Monkeybread Software -
                        fmSyntaxColorizer now also makes your dreams come true: 

                                     ::::::::::::::::::::::::::::::
                                     :: LINE NUMBERS IN SCRIPTS! ::
                                     ::::::::::::::::::::::::::::::

You've got to see it to believe it, so get started today! :-)

Happy FileMaking!

MrWatson

2014-01-13


GET STARTED
-----------

1) Unzip the fmWorkMate archive
2) Copy the MrW/fmWorkMate folder to your Applications/MrW folder
3) Start fmWorkMate
4) Have fun :)


GET SMART
---------

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: fmWorkMate IS STILL IN THE BETA-TESTING PHASE (i.e. it is still being  ::
:: tested and developed and may contain bugs) SO USE IT AT YOUR OWN RISK! ::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Please read 

  fmWorkMate-Disclaimer.txt
  fmWorkMate-Licence.txt
  fmWorkMate-Changes.txt
  fmWorkMate-Acknowledgements

and the Known Issues below.

GET MORE
--------

fmCheckMate, the heart of the tool box, is capable of transforming your code in ways you cannot imagine.

                                           ::::::::::::::::::::::::::::::
                              Download the :: fmCheckMate XSLT Library :: now
                                           ::::::::::::::::::::::::::::::

                                 and transform your work and the way you work

                                          http://www.fmworkmate.com


GET UP-TO-DATE
--------------

Visit http://www.fmworkmate.com (or http://www.mrwatson.de) for the latest information and help.


fmWorkMate: KNOWN ISSUES
-------------------------------

- Not everything is tested.

- On windows the fmxmlsnippet may incorrectly contain doubled end-of-line characters.

- FileMaker itself does not copy & paste all objects 100% correctly (notably the Import Records script step and the context table in field definitions)
Pasting entire tables, scripts and custom functions creates new objects with new internal IDs. So you may want to just copy the contents of an object

- You can break things. Test before you try.

- To keep the download smaller, fmWorkMate only supports english and german. Let us know if you wish to have support for other languages.

- The windows version seems to crash on exit - but does no harm. Somebody please tell me why!
